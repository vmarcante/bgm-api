package br.com.api.bgm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BgmApplicationTests {

	@Test
	void contextLoads() {
	}

}
