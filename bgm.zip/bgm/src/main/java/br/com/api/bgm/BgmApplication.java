package br.com.api.bgm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BgmApplication {

	public static void main(String[] args) {
		SpringApplication.run(BgmApplication.class, args);
	}

}
